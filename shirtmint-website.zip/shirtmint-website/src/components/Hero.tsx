import { motion } from "motion/react";
import { ArrowRight, Sparkles } from "lucide-react";

export const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 z-0">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute top-1/4 -left-20 w-96 h-96 bg-mint/20 rounded-full blur-[120px]"
        />
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.1, 0.15, 0.1],
          }}
          transition={{ duration: 10, repeat: Infinity, delay: 1 }}
          className="absolute bottom-1/4 -right-20 w-[500px] h-[500px] bg-mint/10 rounded-full blur-[150px]"
        />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6"
          >
            <Sparkles className="w-4 h-4 text-mint" />
            <span className="text-xs font-bold uppercase tracking-widest text-mint">
              Professional T-Shirt Designer
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-6xl md:text-8xl font-black mb-6 leading-[1.1]"
          >
            Premium T-Shirt <br />
            <span className="text-mint">Designs That Sell</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-xl md:text-2xl text-white/60 mb-10 max-w-2xl leading-relaxed"
          >
            Professional Graphic Designer specializing in high-selling t-shirt artwork for brands, print-on-demand stores, and merch businesses.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-wrap gap-6"
          >
            <a
              href="#portfolio"
              className="group px-8 py-4 bg-mint text-dark font-bold rounded-xl flex items-center gap-2 hover:scale-105 transition-all glow-mint"
            >
              View My Work
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
            <a
              href="#contact"
              className="px-8 py-4 glass text-white font-bold rounded-xl hover:bg-white/10 transition-all"
            >
              Hire Me
            </a>
          </motion.div>
        </div>
      </div>

      {/* Floating Mockups (Visual Decoration) */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden lg:block w-1/3 h-full pointer-events-none">
        <motion.div
          animate={{
            y: [0, -20, 0],
            rotate: [0, 5, 0],
          }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/4 right-10 w-64 h-80 glass rounded-2xl p-4 rotate-6 shadow-2xl"
        >
          <img
            src="https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&q=80&w=400"
            alt="Design Mockup"
            className="w-full h-full object-cover rounded-lg opacity-80"
            referrerPolicy="no-referrer"
          />
        </motion.div>
        <motion.div
          animate={{
            y: [0, 20, 0],
            rotate: [0, -5, 0],
          }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
          className="absolute bottom-1/4 right-40 w-64 h-80 glass rounded-2xl p-4 -rotate-6 shadow-2xl"
        >
          <img
            src="https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&q=80&w=400"
            alt="Design Mockup"
            className="w-full h-full object-cover rounded-lg opacity-80"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </div>
    </section>
  );
};
