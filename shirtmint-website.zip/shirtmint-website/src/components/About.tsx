import { motion } from "motion/react";
import { User, Award, CheckCircle } from "lucide-react";

export const About = () => {
  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-square rounded-3xl overflow-hidden glass p-4">
              <img
                src="https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?auto=format&fit=crop&q=80&w=800"
                alt="Arafat - Creative Designer"
                className="w-full h-full object-cover rounded-2xl grayscale hover:grayscale-0 transition-all duration-700"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 glass p-6 rounded-2xl glow-mint">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-mint rounded-full flex items-center justify-center text-dark">
                  <Award className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-2xl font-black text-mint">8+ Years</p>
                  <p className="text-xs uppercase tracking-widest text-white/60">Experience</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-black mb-8">
              Meet the <span className="text-mint">Designer</span>
            </h2>
            <p className="text-xl text-white/70 mb-8 leading-relaxed">
              Hi, I'm <span className="text-white font-bold">Arafat</span> — a professional t-shirt graphic designer helping brands create eye-catching designs that sell. I specialize in bold typography, vintage graphics, mascots, and creative merch designs for print-on-demand businesses.
            </p>
            <p className="text-lg text-white/60 mb-10">
              I focus on high-quality, unique artwork that stands out in the marketplace and helps brands grow. Every design is crafted with market trends and brand identity in mind.
            </p>

            <div className="grid grid-cols-2 gap-6">
              {[
                "Unique Artwork",
                "Market Research",
                "Print-Ready Files",
                "Commercial Rights",
              ].map((item) => (
                <div key={item} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-mint" />
                  <span className="font-medium text-white/80">{item}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
