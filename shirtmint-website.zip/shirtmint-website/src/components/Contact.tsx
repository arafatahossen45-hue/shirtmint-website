import { motion } from "motion/react";
import { 
  Mail, 
  Twitter, 
  MessageCircle, 
  Send, 
  ExternalLink,
  MapPin
} from "lucide-react";

const contactMethods = [
  {
    name: "Location",
    value: "Chuadanga, Khulna, Bangladesh",
    href: "https://www.google.com/maps/place/Chuadanga",
    iconUrl: "", // We'll use MapPin icon for this one
    icon: MapPin,
    color: "bg-red-500",
  },
  {
    name: "Email",
    value: "mdarafathossen2146@gmail.com",
    href: "mailto:mdarafathossen2146@gmail.com",
    iconUrl: "https://cdn.simpleicons.org/gmail/white",
    color: "bg-[#EA4335]",
  },
  {
    name: "Instagram",
    value: "@shirtmint_design1",
    href: "https://www.instagram.com/shirtmint_design1/",
    iconUrl: "https://cdn.simpleicons.org/instagram/white",
    color: "bg-[#E4405F]",
  },
  {
    name: "Twitter / X",
    value: "@ThreadBundle0",
    href: "https://x.com/ThreadBundle0",
    iconUrl: "https://cdn.simpleicons.org/x/white",
    color: "bg-[#000000]",
  },
  {
    name: "WhatsApp",
    value: "+880 1408-110553",
    href: "https://wa.me/8801408110553",
    iconUrl: "https://cdn.simpleicons.org/whatsapp/white",
    color: "bg-[#25D366]",
  },
  {
    name: "Telegram",
    value: "@arafat21462",
    href: "https://t.me/arafat21462",
    iconUrl: "https://cdn.simpleicons.org/telegram/white",
    color: "bg-[#26A5E4]",
  },
  {
    name: "Fiverr",
    value: "arafat21462",
    href: "https://www.fiverr.com/arafat21462?public_mode=true",
    iconUrl: "https://cdn.simpleicons.org/fiverr/white",
    color: "bg-[#1DBF73]",
  },
];

export const Contact = () => {
  return (
    <section id="contact" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-mint/5 rounded-full blur-[120px]" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-5xl mx-auto glass rounded-[48px] p-12 md:p-20">
          <div className="grid lg:grid-cols-2 gap-16">
            <div>
              <h2 className="text-5xl md:text-6xl font-black mb-8">
                Let's Work <br />
                <span className="text-mint">Together</span>
              </h2>
              <p className="text-white/60 text-lg mb-12 leading-relaxed">
                Ready to take your brand to the next level with premium t-shirt designs? Reach out through any of these platforms and let's start creating.
              </p>
              
              <div className="space-y-6">
                {contactMethods.map((method, index) => (
                  <motion.a
                    key={method.name}
                    href={method.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-6 group p-4 rounded-2xl hover:bg-white/5 transition-all"
                  >
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white transition-all group-hover:scale-110 group-hover:glow-mint ${method.color}`}>
                      {method.iconUrl ? (
                        <img 
                          src={method.iconUrl} 
                          alt={method.name} 
                          className="w-7 h-7 object-contain" 
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        method.icon && <method.icon className="w-7 h-7" />
                      )}
                    </div>
                    <div>
                      <p className="text-xs font-bold uppercase tracking-widest text-white/40 mb-1">
                        {method.name}
                      </p>
                      <p className="text-lg font-bold group-hover:text-mint transition-colors">
                        {method.value}
                      </p>
                    </div>
                  </motion.a>
                ))}
              </div>
            </div>

            <div className="hidden lg:flex flex-col justify-center items-center text-center">
              <div className="w-64 h-64 bg-mint/10 rounded-full flex items-center justify-center relative mb-10">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 border-2 border-dashed border-mint/30 rounded-full"
                />
                <div className="w-48 h-48 bg-mint rounded-full flex items-center justify-center glow-mint">
                  <Mail className="w-20 h-20 text-dark" />
                </div>
              </div>
              <h3 className="text-3xl font-black mb-4">Available for New Projects</h3>
              <p className="text-white/50">Current Response Time: &lt; 12 Hours</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
