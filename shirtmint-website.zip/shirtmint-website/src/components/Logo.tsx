import { motion } from "motion/react";

export const Logo = ({ className = "w-10 h-10" }: { className?: string }) => {
  return (
    <div className={`relative flex items-center justify-center ${className}`}>
      <motion.svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        {/* T-Shirt Outline */}
        <path
          d="M20 30 L35 20 L45 25 L55 25 L65 20 L80 30 L80 45 L70 45 L70 85 L30 85 L30 45 L20 45 Z"
          stroke="currentColor"
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* Mint Leaf Concept inside */}
        <path
          d="M50 40 C50 40 65 45 65 60 C65 75 50 80 50 80 C50 80 35 75 35 60 C35 45 50 40 50 40 Z"
          fill="var(--color-mint)"
          className="opacity-80"
        />
        <path
          d="M50 40 V80"
          stroke="var(--color-dark)"
          strokeWidth="2"
          strokeLinecap="round"
        />
      </motion.svg>
    </div>
  );
};

export const LogoText = () => (
  <div className="flex items-center gap-2 group cursor-pointer">
    <Logo className="w-8 h-8" />
    <span className="text-xl font-display font-bold tracking-tighter">
      Shirt<span className="text-mint group-hover:text-white transition-colors">Mint</span>
    </span>
  </div>
);
