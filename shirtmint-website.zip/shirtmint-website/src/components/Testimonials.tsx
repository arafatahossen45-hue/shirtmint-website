import { motion } from "motion/react";
import { Quote, Star } from "lucide-react";

const testimonials = [
  {
    name: "James Wilson",
    role: "POD Store Owner",
    text: "Arafat created amazing t-shirt designs for my store. Sales increased instantly. His eye for typography is unmatched.",
    rating: 5,
  },
  {
    name: "Sarah Chen",
    role: "Brand Manager",
    text: "Professional designer with creative ideas. Highly recommended for anyone looking for premium merch designs.",
    rating: 5,
  },
  {
    name: "Mike Thompson",
    role: "E-commerce Entrepreneur",
    text: "Fast, reliable, and incredibly talented. He understood our brand vibe perfectly from the first draft.",
    rating: 5,
  },
];

export const Testimonials = () => {
  return (
    <section className="py-24 overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-black mb-6">
            Client <span className="text-mint">Testimonials</span>
          </h2>
          <p className="text-white/60 text-lg">
            What brands and entrepreneurs say about working with ShirtMint.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t, index) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="glass p-10 rounded-[32px] relative group"
            >
              <Quote className="absolute top-8 right-8 w-10 h-10 text-mint/10 group-hover:text-mint/20 transition-colors" />
              
              <div className="flex gap-1 mb-6">
                {[...Array(t.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-mint text-mint" />
                ))}
              </div>
              
              <p className="text-lg text-white/80 mb-8 italic leading-relaxed">
                "{t.text}"
              </p>
              
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center font-bold text-mint">
                  {t.name[0]}
                </div>
                <div>
                  <h4 className="font-bold text-white">{t.name}</h4>
                  <p className="text-xs text-white/40 uppercase tracking-widest">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
