import { LogoText } from "./Logo";
import { MapPin } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="py-16 border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-12 mb-12">
          <div className="flex flex-col items-center md:items-start gap-4">
            <LogoText />
            <div className="flex items-center gap-2 text-white/40 text-sm">
              <MapPin className="w-4 h-4 text-mint" />
              <span>Chuadanga, Khulna, Bangladesh</span>
            </div>
          </div>
          
          <div className="flex flex-wrap justify-center gap-8 text-sm font-medium text-white/50">
            <a href="#home" className="hover:text-mint transition-colors">Home</a>
            <a href="#about" className="hover:text-mint transition-colors">About</a>
            <a href="#services" className="hover:text-mint transition-colors">Services</a>
            <a href="#portfolio" className="hover:text-mint transition-colors">Portfolio</a>
            <a href="#contact" className="hover:text-mint transition-colors">Contact</a>
          </div>
          
          <div className="flex gap-4">
            {[
              { name: "Instagram", iconUrl: "https://cdn.simpleicons.org/instagram/white", href: "https://www.instagram.com/shirtmint_design1/" },
              { name: "X", iconUrl: "https://cdn.simpleicons.org/x/white", href: "https://x.com/ThreadBundle0" },
              { name: "WhatsApp", iconUrl: "https://cdn.simpleicons.org/whatsapp/white", href: "https://wa.me/8801408110553" },
              { name: "Telegram", iconUrl: "https://cdn.simpleicons.org/telegram/white", href: "https://t.me/arafat21462" },
              { name: "Fiverr", iconUrl: "https://cdn.simpleicons.org/fiverr/white", href: "https://www.fiverr.com/arafat21462?public_mode=true" },
              { name: "Gmail", iconUrl: "https://cdn.simpleicons.org/gmail/white", href: "mailto:mdarafathossen2146@gmail.com" },
            ].map((social, i) => (
              <a
                key={i}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 glass rounded-full flex items-center justify-center text-white/60 hover:text-mint hover:border-mint/50 transition-all"
              >
                <img 
                  src={social.iconUrl} 
                  alt={social.name} 
                  className="w-5 h-5 object-contain opacity-60 group-hover:opacity-100 transition-opacity" 
                  referrerPolicy="no-referrer"
                />
              </a>
            ))}
          </div>
        </div>
        
        <div className="text-center border-t border-white/5 pt-12">
          <p className="text-white/30 text-sm">
            © 2026 ShirtMint — Premium T-Shirt Design Studio. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};
