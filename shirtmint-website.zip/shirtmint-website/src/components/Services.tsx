import { motion } from "motion/react";
import { 
  Shirt, 
  Package, 
  History, 
  Ghost, 
  ShieldCheck,
  Coffee
} from "lucide-react";

const services = [
  {
    title: "Custom T-Shirt Design",
    description: "Unique, bespoke designs tailored to your brand's specific vision and target audience.",
    icon: Shirt,
  },
  {
    title: "POD Design Packs",
    description: "High-volume design collections optimized for Print-On-Demand platforms like Redbubble and Merch by Amazon.",
    icon: Package,
  },
  {
    title: "Vintage & Retro Graphics",
    description: "Authentic 80s and 90s style graphics with distressed textures and classic typography.",
    icon: History,
  },
  {
    title: "Mascot & Character Designs",
    description: "Custom illustrated mascots and characters that give your brand a unique personality.",
    icon: Ghost,
  },
  {
    title: "Merch Brand Support",
    description: "Complete design support for growing merch brands, from concept to final production files.",
    icon: ShieldCheck,
  },
  {
    title: "Custom Mug Design",
    description: "Creative and eye-catching wrap-around designs for coffee mugs and drinkware products.",
    icon: Coffee,
  },
];

export const Services = () => {
  return (
    <section id="services" className="py-24 bg-charcoal/50">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-black mb-6">
            Professional <span className="text-mint">Services</span>
          </h2>
          <p className="text-white/60 text-lg">
            Elevate your brand with high-end graphic design solutions specifically crafted for the apparel industry.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="glass p-8 rounded-3xl group hover:border-mint/30 transition-all"
            >
              <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-mint group-hover:text-dark transition-colors">
                <service.icon className="w-7 h-7" />
              </div>
              <h3 className="text-2xl font-bold mb-4 group-hover:text-mint transition-colors">
                {service.title}
              </h3>
              <p className="text-white/50 leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
