import { motion } from "motion/react";
import { Logo } from "./Logo";

export const Loader = () => {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
      className="fixed inset-0 z-[100] bg-dark flex flex-col items-center justify-center"
    >
      <Logo className="w-24 h-24 mb-8" />
      <div className="w-48 h-1 bg-white/10 rounded-full overflow-hidden relative">
        <motion.div
          initial={{ x: "-100%" }}
          animate={{ x: "100%" }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
          className="absolute inset-0 bg-mint glow-mint"
        />
      </div>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-6 text-xs uppercase tracking-[0.3em] text-white/40 font-bold"
      >
        Crafting Excellence
      </motion.p>
    </motion.div>
  );
};
