import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";
import { ExternalLink, Search, X, MessageCircle, Send } from "lucide-react";

const categories = ["All", "Vintage", "Typography", "Modern"];

const projects = [
  {
    id: 1,
    title: "Retro Sunset Adventure",
    category: "Vintage",
    image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: 2,
    title: "Urban Skull Graphic",
    category: "Modern",
    image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: 3,
    title: "Minimalist Typography",
    category: "Typography",
    image: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: 4,
    title: "Dark Aesthetic Illustration",
    category: "Modern",
    image: "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: 5,
    title: "Vintage California Dream",
    category: "Vintage",
    image: "https://images.unsplash.com/photo-1527719327859-c6ce80353573?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: 6,
    title: "Bold Streetwear Concept",
    category: "Modern",
    image: "https://images.unsplash.com/photo-1564859228273-274232fdb516?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: 7,
    title: "Bold Statement Tee",
    category: "Typography",
    image: "https://images.unsplash.com/photo-1583744946564-b52ac1c389c8?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: 8,
    title: "Script Aesthetic Design",
    category: "Typography",
    image: "https://images.unsplash.com/photo-1562157873-818bc0726f68?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: 9,
    title: "Classic Vintage Badge",
    category: "Vintage",
    image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=800",
  },
];

export const Portfolio = () => {
  const [filter, setFilter] = useState("All");
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);

  const filteredProjects = filter === "All" 
    ? projects 
    : projects.filter(p => p.category === filter);

  const handleContact = (platform: 'whatsapp' | 'telegram' | 'instagram' | 'twitter') => {
    if (!selectedProject) return;
    
    const message = encodeURIComponent(`Hi, I want to design a ${selectedProject.category.toLowerCase()} t-shirt.`);
    const links = {
      whatsapp: `https://wa.me/8801408110553?text=${message}`,
      telegram: `https://t.me/arafat21462?text=${message}`,
      instagram: `https://www.instagram.com/shirtmint_design1/`,
      twitter: `https://x.com/intent/tweet?text=${message}%20@ThreadBundle0`
    };
    
    window.open(links[platform], '_blank');
    setSelectedProject(null);
  };

  return (
    <section id="portfolio" className="py-24">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-black mb-6">
              Featured <span className="text-mint">Designs</span>
            </h2>
            <p className="text-white/60 text-lg">
              A curated selection of high-selling t-shirt artwork and brand identities.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
                  filter === cat 
                    ? "bg-mint text-dark glow-mint" 
                    : "glass text-white/60 hover:text-white"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                className="group relative aspect-[3/4] rounded-3xl overflow-hidden glass"
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-dark/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-center items-center p-8 text-center">
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    whileInView={{ y: 0, opacity: 1 }}
                    className="mb-4"
                  >
                    <span className="text-xs font-bold uppercase tracking-widest text-mint mb-2 block">
                      {project.category}
                    </span>
                    <h3 className="text-2xl font-black mb-6">{project.title}</h3>
                  </motion.div>
                  
                  <div className="flex gap-4">
                    <button 
                      onClick={() => setSelectedProject(project)}
                      className="px-6 py-3 bg-mint text-dark font-bold rounded-xl flex items-center gap-2 hover:scale-105 transition-all glow-mint"
                    >
                      Hire for this Style
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Contact Modal */}
        <AnimatePresence>
          {selectedProject && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSelectedProject(null)}
                className="absolute inset-0 bg-dark/90 backdrop-blur-sm"
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative w-full max-w-md glass p-8 rounded-[32px] shadow-2xl border border-white/10"
              >
                <button 
                  onClick={() => setSelectedProject(null)}
                  className="absolute top-6 right-6 text-white/40 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>

                <div className="text-center mb-8">
                  <div className="w-20 h-20 mx-auto mb-6 rounded-2xl overflow-hidden border-2 border-mint/30">
                    <img src={selectedProject.image} alt="" className="w-full h-full object-cover" />
                  </div>
                  <h3 className="text-2xl font-black mb-2">Order {selectedProject.category} Style</h3>
                  <p className="text-white/60">Choose your preferred platform to start designing your custom t-shirt.</p>
                </div>

                <div className="grid grid-cols-1 gap-3">
                  <button
                    onClick={() => handleContact('whatsapp')}
                    className="w-full py-3.5 bg-[#25D366] text-white font-bold rounded-2xl flex items-center justify-center gap-3 hover:scale-[1.02] transition-all shadow-lg shadow-[#25D366]/20"
                  >
                    <img 
                      src="https://cdn.simpleicons.org/whatsapp/white" 
                      alt="WhatsApp" 
                      className="w-5 h-5 object-contain" 
                      referrerPolicy="no-referrer"
                    />
                    WhatsApp
                  </button>
                  <button
                    onClick={() => handleContact('telegram')}
                    className="w-full py-3.5 bg-[#26A5E4] text-white font-bold rounded-2xl flex items-center justify-center gap-3 hover:scale-[1.02] transition-all shadow-lg shadow-[#26A5E4]/20"
                  >
                    <img 
                      src="https://cdn.simpleicons.org/telegram/white" 
                      alt="Telegram" 
                      className="w-5 h-5 object-contain" 
                      referrerPolicy="no-referrer"
                    />
                    Telegram
                  </button>
                  <button
                    onClick={() => handleContact('instagram')}
                    className="w-full py-3.5 bg-[#E4405F] text-white font-bold rounded-2xl flex items-center justify-center gap-3 hover:scale-[1.02] transition-all shadow-lg shadow-[#E4405F]/20"
                  >
                    <img 
                      src="https://cdn.simpleicons.org/instagram/white" 
                      alt="Instagram" 
                      className="w-5 h-5 object-contain" 
                      referrerPolicy="no-referrer"
                    />
                    Instagram
                  </button>
                  <button
                    onClick={() => handleContact('twitter')}
                    className="w-full py-3.5 bg-[#000000] text-white font-bold rounded-2xl flex items-center justify-center gap-3 hover:scale-[1.02] transition-all shadow-lg shadow-black/20"
                  >
                    <img 
                      src="https://cdn.simpleicons.org/x/white" 
                      alt="Twitter" 
                      className="w-5 h-5 object-contain" 
                      referrerPolicy="no-referrer"
                    />
                    Twitter / X
                  </button>
                </div>

                <p className="mt-8 text-center text-xs text-white/40">
                  A pre-filled message will be ready: <br />
                  <span className="text-mint/60 italic mt-1 block">
                    "Hi, I want to design a {selectedProject.category.toLowerCase()} t-shirt."
                  </span>
                </p>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};
