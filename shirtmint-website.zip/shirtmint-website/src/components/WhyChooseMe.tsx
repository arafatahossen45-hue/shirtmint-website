import { motion } from "motion/react";
import { 
  Zap, 
  Star, 
  Clock, 
  MessageSquare, 
  TrendingUp 
} from "lucide-react";

const features = [
  {
    title: "Market-Proven Designs",
    description: "I create artwork that doesn't just look good but is engineered to sell in competitive POD marketplaces like Amazon and Shopify.",
    icon: TrendingUp,
  },
  {
    title: "Print-Ready Precision",
    description: "Every design is delivered in high-resolution (300 DPI) with perfect color separation for flawless printing on any garment.",
    icon: Star,
  },
  {
    title: "Brand Identity Focus",
    description: "I don't just make graphics; I build visual identities that resonate with your specific target audience and niche.",
    icon: Zap,
  },
  {
    title: "Commercial Rights Included",
    description: "You get full ownership and commercial rights to every design, allowing you to scale your business without any legal limits.",
    icon: MessageSquare,
  },
  {
    title: "Unlimited Revisions",
    description: "Your satisfaction is my priority. I offer unlimited revisions to ensure the final design perfectly matches your brand vision.",
    icon: Clock,
  },
];

export const WhyChooseMe = () => {
  return (
    <section className="py-24 bg-charcoal/30">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-black mb-8">
              Why <span className="text-mint">Choose Me</span>
            </h2>
            <p className="text-white/60 text-lg mb-12 leading-relaxed">
              With years of experience in the apparel industry, I understand the delicate balance between artistic creativity and market viability. My goal is to help your brand stand out and succeed.
            </p>
            
            <div className="space-y-8">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex gap-6 group"
                >
                  <div className="flex-shrink-0 w-12 h-12 glass rounded-xl flex items-center justify-center text-mint group-hover:bg-mint/20 transition-colors duration-300">
                    <feature.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2 group-hover:text-mint transition-colors duration-300">{feature.title}</h3>
                    <p className="text-white/50">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative hidden lg:block"
          >
            <div className="absolute inset-0 bg-mint/10 blur-[100px] rounded-full" />
            <div className="relative glass p-8 rounded-[40px] rotate-3 hover:rotate-0 transition-transform duration-500">
              <img
                src="https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&q=80&w=800"
                alt="Creative Workspace"
                className="w-full h-auto rounded-[30px] shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
